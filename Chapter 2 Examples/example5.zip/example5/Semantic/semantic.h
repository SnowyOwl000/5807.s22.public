//
// Created by bob on 1/22/22.
//

#ifndef _SEMANTIC_H
#define _SEMANTIC_H

#include <string>
#include <map>
#include "../ParseTree/parseTree.h"

extern std::map<std::string,uint32_t>
    varMap;

bool semanticChecks(uint32_t);

void dumpVars();

#endif //_SEMANTIC_H
