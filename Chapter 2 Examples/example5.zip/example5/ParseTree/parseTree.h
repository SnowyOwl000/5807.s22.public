//
// Created by bob on 1/22/22.
//

#ifndef _PARSETREE_H
#define _PARSETREE_H

#include <cstdint>
#include <vector>

enum NodeTypes {
    NODE_NUM,
    NODE_VAR,
    NODE_ADD,
    NODE_SUB,
    NODE_MUL,
    NODE_DIV,
    NODE_MOD,
    NODE_NEG,
    NODE_ASSIGN,
    NODE_STMT
};

struct TreeNode {
    NodeTypes
        type;               // node type
    int32_t
        iVal;               // integer value for numbers
    char *
        sVal;               // string val for ids
    uint32_t
        left,right,         // left and right subtree root indexes
        iFirst,iLast;       // first and last icode instructions
};

extern uint32_t
    treeRoot;

extern std::vector<TreeNode>
    tree;

uint32_t
    makeNumNode(int32_t),
    makeVarNode(char *),
    makeAddNode(uint32_t,uint32_t),
    makeSubNode(uint32_t,uint32_t),
    makeMulNode(uint32_t,uint32_t),
    makeDivNode(uint32_t,uint32_t),
    makeModNode(uint32_t,uint32_t),
    makeNegNode(uint32_t),
    makeAssignNode(uint32_t,uint32_t),
    makeStmtNode(uint32_t,uint32_t);

void
    dumpTree();

#endif //_PARSETREE_H
