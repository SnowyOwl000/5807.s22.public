//
// Created by bob on 1/22/22.
//

#include <iostream>
#include <iomanip>
#include <vector>
#include "parseTree.h"

using namespace std;

uint32_t
    treeRoot;

vector<TreeNode>
    tree;

static uint32_t
    nextNode = 0;

uint32_t makeNumNode(int32_t val) {
    TreeNode
        tmp{};

    tmp.type = NODE_NUM;
    tmp.iVal = val;
    tmp.left = tmp.right = 0xffffffff;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeVarNode(char *val) {
    TreeNode
            tmp{};

    tmp.type = NODE_VAR;
    tmp.sVal = val;
    tmp.left = tmp.right = 0xffffffff;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeAddNode(uint32_t left,uint32_t right) {
    TreeNode
        tmp{};

    tmp.type = NODE_ADD;
    tmp.left = left;
    tmp.right = right;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeSubNode(uint32_t left,uint32_t right) {
    TreeNode
        tmp{};

    tmp.type = NODE_SUB;
    tmp.left = left;
    tmp.right = right;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeMulNode(uint32_t left,uint32_t right) {
    TreeNode
        tmp{};

    tmp.type = NODE_MUL;
    tmp.left = left;
    tmp.right = right;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeDivNode(uint32_t left,uint32_t right) {
    TreeNode
        tmp{};

    tmp.type = NODE_DIV;
    tmp.left = left;
    tmp.right = right;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeModNode(uint32_t left,uint32_t right) {
    TreeNode
        tmp{};

    tmp.type = NODE_MOD;
    tmp.left = left;
    tmp.right = right;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeNegNode(uint32_t left) {
    TreeNode
        tmp{};

    tmp.type = NODE_NEG;
    tmp.left = left;
    tmp.right = 0xffffffff;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeAssignNode(uint32_t left,uint32_t right) {
    TreeNode
        tmp{};

    tmp.type = NODE_ASSIGN;
    tmp.left = left;
    tmp.right = right;

    tree.push_back(tmp);

    return nextNode++;
}

uint32_t makeStmtNode(uint32_t left,uint32_t right) {
    TreeNode
        tmp{};

    tmp.type = NODE_STMT;
    tmp.left = left;
    tmp.right = right;

    tree.push_back(tmp);

    return nextNode++;
}

static const char *getType(NodeTypes type) {
    switch (type) {
        case NODE_VAR:
            return "VAR";
        case NODE_NUM:
            return "NUM";
        case NODE_ASSIGN:
            return "ASSIGN";
        case NODE_NEG:
            return "NEG";
        case NODE_DIV:
            return "DIV";
        case NODE_ADD:
            return "ADD";
        case NODE_MOD:
            return "MOD";
        case NODE_MUL:
            return "MUL";
        case NODE_STMT:
            return "STMT";
        case NODE_SUB:
            return "SUB";
        default:
            return "error";
    }
}

void dumpTree() {

    cout << "Tree root: " << treeRoot << "\nNodes:\n  n        left        right       type      val" << endl;
    cout << "-----   ----------   ----------   ------   --------" << endl;
    for (uint32_t i=0;i<nextNode;i++) {
        cout << setw(5) << i << "   " << setw(10) << tree[i].left << "   "
            << setw(10) << tree[i].right << "   "
             << setw(6) << getType(tree[i].type) << "   ";
        if (tree[i].type == NODE_NUM)
            cout << tree[i].iVal;
        if (tree[i].type == NODE_VAR)
            cout << tree[i].sVal;
        cout << endl;
    }
}


