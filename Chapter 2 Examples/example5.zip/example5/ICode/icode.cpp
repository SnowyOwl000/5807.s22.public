//
// Created by bob on 1/22/22.
//

#include <iostream>
#include <iomanip>
#include "icode.h"

using namespace std;

vector<ICode>
    iCode;

static uint32_t
    nextInstruction = 0;

#pragma clang diagnostic push
#pragma ide diagnostic ignored "misc-no-recursion"
void makeIcode(uint32_t n) {
    ICode
        inst{};

    // null index; do nothing
    if (n == 0xffffffff)
        return;

    switch (tree[n].type) {
        // stmt nodes form a backbone (list) containing individual expressions
        case NODE_STMT:
            makeIcode(tree[n].left);
            makeIcode(tree[n].right);
            break;

        // number nodes load into the next temporary
        case NODE_NUM:
            tree[n].iFirst = tree[n].iLast = nextInstruction;

            inst.inst = I_MOVE;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = tree[n].iVal;
            inst.src1Region = I_REG_NUMS;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        // var nodes (on the rhs of an ASSIGN) are like numbers
        case NODE_VAR:
            tree[n].iFirst = tree[n].iLast = nextInstruction;

            inst.inst = I_MOVE;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = varMap[tree[n].sVal];
            inst.src1Region = I_REG_VARS;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        // binary operand nodes are all alike
        case NODE_ADD:
            makeIcode(tree[n].left);
            makeIcode(tree[n].right);

            tree[n].iFirst = tree[tree[n].left].iFirst;
            tree[n].iLast = nextInstruction;

            inst.inst = I_ADDI;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = iCode[tree[tree[n].left].iLast].destOffset;
            inst.src1Region = iCode[tree[tree[n].left].iLast].destRegion;

            inst.src2Offset = iCode[tree[tree[n].right].iLast].destOffset;
            inst.src2Region = iCode[tree[tree[n].right].iLast].destRegion;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        case NODE_SUB:
            makeIcode(tree[n].left);
            makeIcode(tree[n].right);

            tree[n].iFirst = tree[tree[n].left].iFirst;
            tree[n].iLast = nextInstruction;

            inst.inst = I_SUBI;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = iCode[tree[tree[n].left].iLast].destOffset;
            inst.src1Region = iCode[tree[tree[n].left].iLast].destRegion;

            inst.src2Offset = iCode[tree[tree[n].right].iLast].destOffset;
            inst.src2Region = iCode[tree[tree[n].right].iLast].destRegion;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        case NODE_MUL:
            makeIcode(tree[n].left);
            makeIcode(tree[n].right);

            tree[n].iFirst = tree[tree[n].left].iFirst;
            tree[n].iLast = nextInstruction;

            inst.inst = I_MULI;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = iCode[tree[tree[n].left].iLast].destOffset;
            inst.src1Region = iCode[tree[tree[n].left].iLast].destRegion;

            inst.src2Offset = iCode[tree[tree[n].right].iLast].destOffset;
            inst.src2Region = iCode[tree[tree[n].right].iLast].destRegion;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        case NODE_DIV:
            makeIcode(tree[n].left);
            makeIcode(tree[n].right);

            tree[n].iFirst = tree[tree[n].left].iFirst;
            tree[n].iLast = nextInstruction;

            inst.inst = I_DIVI;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = iCode[tree[tree[n].left].iLast].destOffset;
            inst.src1Region = iCode[tree[tree[n].left].iLast].destRegion;

            inst.src2Offset = iCode[tree[tree[n].right].iLast].destOffset;
            inst.src2Region = iCode[tree[tree[n].right].iLast].destRegion;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        case NODE_MOD:
            makeIcode(tree[n].left);
            makeIcode(tree[n].right);

            tree[n].iFirst = tree[tree[n].left].iFirst;
            tree[n].iLast = nextInstruction;

            inst.inst = I_MODI;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = iCode[tree[tree[n].left].iLast].destOffset;
            inst.src1Region = iCode[tree[tree[n].left].iLast].destRegion;

            inst.src2Offset = iCode[tree[tree[n].right].iLast].destOffset;
            inst.src2Region = iCode[tree[tree[n].right].iLast].destRegion;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        case NODE_NEG:
            makeIcode(tree[n].left);

            tree[n].iFirst = tree[tree[n].left].iFirst;
            tree[n].iLast = nextInstruction;

            inst.inst = I_NEGI;

            inst.destOffset = nextInstruction;
            inst.destRegion = I_REG_TEMPS;

            inst.src1Offset = iCode[tree[tree[n].left].iLast].destOffset;
            inst.src1Region = iCode[tree[tree[n].left].iLast].destRegion;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        // assign nodes (a) move rhs to var in lhs and (b) return lhs
        // part (b) is done implicitly by having dest be the lhs var
        case NODE_ASSIGN:
            makeIcode(tree[n].right);

            tree[n].iFirst = tree[tree[n].right].iFirst;
            tree[n].iLast = nextInstruction;

            inst.inst = I_MOVE;

            inst.destOffset = varMap[tree[tree[n].left].sVal];
            inst.destRegion = I_REG_VARS;

            inst.src1Offset = iCode[tree[tree[n].right].iLast].destOffset;
            inst.src1Region = iCode[tree[tree[n].right].iLast].destRegion;

            iCode.push_back(inst);

            nextInstruction++;
            break;

        default:
            break;
    }
}
#pragma clang diagnostic pop

void dumpIcode() {

    for (uint32_t i=0;i<nextInstruction;i++) {
        if (iCode[i].destRegion == I_REG_TEMPS)
            cout << 't';
        else if (iCode[i].destRegion == I_REG_VARS)
            cout << 'v';
        else {
            cout << "Error: bad dest region" << endl;
            continue;
        }
        cout << setw(3) << left << iCode[i].destOffset << " <-- ";

        switch (iCode[i].inst) {
            case I_MOVE:
                if (iCode[i].src1Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src1Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src1Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src1Offset << endl;
                break;

            case I_ADDI:
                cout << "iADD ";
                if (iCode[i].src1Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src1Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src1Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src1Offset << ',';

                if (iCode[i].src2Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src2Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src2Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src2Offset << endl;

                break;

            case I_SUBI:
                cout << "iSUB ";
                if (iCode[i].src1Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src1Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src1Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src1Offset << ',';

                if (iCode[i].src2Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src2Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src2Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src2Offset << endl;

                break;
            case I_MULI:
                cout << "iMUL ";
                if (iCode[i].src1Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src1Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src1Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src1Offset << ',';

                if (iCode[i].src2Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src2Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src2Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src2Offset << endl;

                break;

            case I_DIVI:
                cout << "iDIV ";
                if (iCode[i].src1Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src1Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src1Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src1Offset << ',';

                if (iCode[i].src2Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src2Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src2Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src2Offset << endl;

                break;

            case I_MODI:
                cout << "iMOD ";
                if (iCode[i].src1Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src1Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src1Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src1Offset << ',';

                if (iCode[i].src2Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src2Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src2Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src2Offset << endl;

                break;

            case I_NEGI:
                cout << "iNEG ";
                if (iCode[i].src1Region == I_REG_TEMPS)
                    cout << 't';
                else if (iCode[i].src1Region == I_REG_VARS)
                    cout << 'v';
                else if (iCode[i].src1Region != I_REG_NUMS)
                    cout << "Error: Invalid source region" << endl;
                cout << setw(3) << iCode[i].src1Offset << endl;

                break;

            default:
                cout << "Error: Invalid intermediate code instruction" << endl;
        }
    }
}