//
// Created by bob on 1/22/22.
//

#ifndef _ICODE_H
#define _ICODE_H

#include <vector>
#include "../ParseTree/parseTree.h"
#include "../Semantic/semantic.h"

enum ICodeInstructions {
    I_MOVE,
    I_ADDI,
    I_SUBI,
    I_MULI,
    I_DIVI,
    I_MODI,
    I_NEGI
};

enum ICodeDataRegion {
    I_REG_VARS,
    I_REG_TEMPS,
    I_REG_NUMS
};

struct ICode {
    ICodeInstructions
        inst;
    uint32_t
        destOffset,
        src1Offset,
        src2Offset;
    ICodeDataRegion
        destRegion,
        src1Region,
        src2Region;
};

extern std::vector<ICode>
    iCode;

void makeIcode(uint32_t);

void dumpIcode();

#endif //_ICODE_H
