//
// Created by bob on 1/20/22.
//

#ifndef _TOKENS_H
#define _TOKENS_H

enum Tokens {
    TOK_ID = 261,
    TOK_NUM = 262,
    TOK_PLUS = 263,
    TOK_MINUS = 264,
    TOK_STAR = 265,
    TOK_SLASH = 266,
    TOK_PERC = 267,
    TOK_ASSIGN = 268,
    TOK_LPAR = 269,
    TOK_RPAR = 270,
    TOK_EOF = 271,
    TOK_ERR = 272
};

#endif //_TOKENS_H
