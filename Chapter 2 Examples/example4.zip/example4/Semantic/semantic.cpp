//
// Created by bob on 1/22/22.
//

#include <iostream>
#include <iomanip>
#include <map>
#include "semantic.h"

using namespace std;

map<string,uint32_t>
    varMap;

uint32_t
    nextOffset = 0;

#pragma clang diagnostic push
#pragma ide diagnostic ignored "misc-no-recursion"
bool semanticChecks(uint32_t n) {
    bool
        okay;

    // null node, nothing to do
    if (n == 0xffffffff)
        return true;

    // assign node; process right side, then define var in left side
    if (tree[n].type == NODE_ASSIGN) {
        okay = semanticChecks(tree[n].right);
        varMap[tree[tree[n].left].sVal] = nextOffset;
        nextOffset += 4;

        return okay;
    }

    // var node; make sure it's varMap
    if (tree[n].type == NODE_VAR) {
        if (varMap.find(tree[n].sVal) == varMap.end()) {
            cout << "Error: Variable '" << tree[n].sVal << "' not defined" << endl;
            return false;
        } else
            return true;
    }

    // other nodes; check both children
    okay = semanticChecks(tree[n].left);
    okay = semanticChecks(tree[n].right) && okay;

    return okay;
}
#pragma clang diagnostic pop

void dumpVars() {

    cout << "  Offset      Var\n----------   ------" << endl;
    for (auto & i : varMap)
        cout << setw(10) << i.second << "   " << i.first << endl;
}