//
// Created by bob on 1/22/22.
//

#ifndef _SEMANTIC_H
#define _SEMANTIC_H

#include "../ParseTree/parseTree.h"

bool semanticChecks(uint32_t);

void dumpVars();

#endif //_SEMANTIC_H
