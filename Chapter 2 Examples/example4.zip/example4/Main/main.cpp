#include <iostream>
#include "../Parser/parser.hpp"
#include "../ParseTree/parseTree.h"
#include "../Semantic/semantic.h"
#include "../ICode/icode.h"

using namespace std;

extern "C"
int
yylex();

extern char *
    yytext;

int main() {
    int
        token;

    /*
    do {
        token = yylex();

        cout << "Token type: " << token << "   lexeme: '" << yytext << "'" << endl;
    } while (token != TOK_EOF);
    */

    yyparse();

    dumpTree();

    if (semanticChecks(treeRoot)) {

        dumpVars();

        makeIcode(treeRoot);

        dumpIcode();
    }

    return 0;
}
